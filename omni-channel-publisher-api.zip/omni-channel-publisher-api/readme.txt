=== OmniChannel Publisher API ===
Contributors: phkcorp2005
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=9674139
Tags: amazon, publisher api
Requires at least: 4.3.1
Tested up to: 4.3
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Populate products from Amazon affiliates categories/products

== Description ==

Populate products from Amazon affiliates categories/products for either Ready Eccommerce of WooCoomerce
shopping carts/stores.

== Installation ==

To instal this plugin, follow these steps:

1. Download the plugin and upload to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Create categories from the Ready Ecommerce or WooCommerce menu
4. Generate AWS Secrity Credentials from the AWS Console
5. Go to Setting|OmniChannel Publishing API, and enter your AWS security credentials, choose an associate tag.
6. Press `Save`
7. Select a category and press Get Amazon products
8. Choose the products you want to include and press `Add Selected`.

== Frequently Asked Questions ==

Please do not be afraid of asking questions?


== Changelog ==

= 1.1 =
* Release version from github.com


